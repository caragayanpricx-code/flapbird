# Flappy Game

A simple browser flappy game. Losing plays a jumpscare.

## Customize
Put your files in this folder, then edit the top of the script in `index.html`:

```js
const BIRD_SRC='bird.png';
const VIDEO_SRC='scare.mp4';
```

Leave them as `''` to use the yellow square and the built-in scare.

## Run
Double-click `index.html`, or use the Live Server extension in VS Code.

## Put it online (GitHub Pages)
1. Push this folder to a GitHub repository.
2. Repo **Settings > Pages**, set the source to the `main` branch, root folder.
3. Open the link GitHub gives you.
